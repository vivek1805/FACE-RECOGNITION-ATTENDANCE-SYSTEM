import os
from tkinter import *
from tkinter import ttk
from typing import Pattern
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import cv2



class Developer:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1920x1080+0+0")
        self.root.title("face Recognition System")
        title_lbl1=Label(self.root,text="Developer",font=("times new roman",35,"bold"),bg="red",fg="white")
        title_lbl1.place(x=0,y=0,width=1550,height=45)

        img_top1=Image.open(r"C:/Users/nitis/Documents/Face_Recognition_Projects/photos/dev.jpg")
        img_top1=img_top1.resize((1530,720),Image.ANTIALIAS)
        self.photoimg_top1=ImageTk.PhotoImage(img_top1)

        f_lbl1=Label(self.root,image=self.photoimg_top1)
        f_lbl1.place(x=0,y=55,width=1530,height=720)

        main_frame=Frame(f_lbl1,bd=2,bg="white")
        main_frame.place(x=1000,y=0,width=500,height=600)

        img_top2=Image.open(r"C:/Users/nitis/Documents/Face_Recognition_Projects/photos/nn.png")
        img_top2=img_top2.resize((200,200),Image.ANTIALIAS)
        self.photoimg_top2=ImageTk.PhotoImage(img_top2)

        f_lbl2=Label(main_frame,image=self.photoimg_top2)
        f_lbl2.place(x=300,y=0,width=200,height=200)

        dev_label=Label(main_frame,text="Project Team Members:",font=("times new roman",13,"bold"),bg="white")
        dev_label.place(x=0,y=5)
        dev_label=Label(main_frame,text="Nitish kumar Nirala(171051090041) (Team Leader)",font=("times new roman",13,"bold"),bg="white")
        dev_label.place(x=0,y=30)
        dev_label=Label(main_frame,text="Vikash kumar(17105109006)",font=("times new roman",13,"bold"),bg="white")
        dev_label.place(x=0,y=60)
        dev_label=Label(main_frame,text="Vidya Sagar(17105109039)",font=("times new roman",13,"bold"),bg="white")
        dev_label.place(x=0,y=90)
        dev_label=Label(main_frame,text="Vivek kumar(17108109040)",font=("times new roman",13,"bold"),bg="white")
        dev_label.place(x=0,y=120)

        img_top3=Image.open(r"C:/Users/nitis/Documents/Face_Recognition_Projects/photos/dev1.jpg")
        img_top3=img_top3.resize((500,390),Image.ANTIALIAS)
        self.photoimg_top3=ImageTk.PhotoImage(img_top3)

        f_lbl3=Label(main_frame,image=self.photoimg_top3)
        f_lbl3.place(x=0,y=210,width=500,height=390)






if __name__=="__main__":
    root=Tk()
    obj=Developer(root)
    root.mainloop()