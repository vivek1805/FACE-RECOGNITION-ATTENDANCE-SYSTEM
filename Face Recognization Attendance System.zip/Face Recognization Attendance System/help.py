import os
from tkinter import *
from tkinter import ttk
from typing import Pattern
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import cv2



class Help:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1920x1080+0+0")
        self.root.title("face Recognition System")
        title_lbl1=Label(self.root,text="Help",font=("times new roman",35,"bold"),bg="red",fg="white")
        title_lbl1.place(x=0,y=0,width=1550,height=45)

        img_top2=Image.open(r"C:/Users/nitis/Documents/Face_Recognition_Projects/photos/help1.jpeg")
        img_top2=img_top2.resize((1530,720),Image.ANTIALIAS)
        self.photoimg_top2=ImageTk.PhotoImage(img_top2)
        f_lbl2=Label(self.root,image=self.photoimg_top2)
        f_lbl2.place(x=0,y=55,width=1530,height=720)

        help_label=Label(f_lbl2,text="Email: nitishnirala2k17@gmail.com",font=("times new roman",13,"bold"),fg="blue",bg="white")
        help_label.place(x=550,y=220)


if __name__=="__main__":
    root=Tk()
    obj=Help(root)
    root.mainloop()