

import mysql.connector as c
con=c.connect(host="localhost", user="root", passwd="12345",database="university")
if con.is_connected():
    print("successfully Connected...")
else:
    print("Some Connectivity Issue...")
