import mysql.connector
conn=mysql.connector.connect(host="localhost",username="root",password="12345",database="face_recognition")
if conn.is_connected()==True:
    print("Connection established...")
else:
    print("Not Connected...")
