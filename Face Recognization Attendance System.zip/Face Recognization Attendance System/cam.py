import cv2
import time
import numpy as np
cap = cv2.VideoCapture(0)
while(cap.isOpened()):
    #Get frame
   # "time.sleep(1)
    ret, frame = cap.read()
    #"time.sleep(1)
    # Show frame
    cv2.imshow("Flame", frame)
    #Ends halfway when the #q key is pressed
    if cv2.waitKey(1)&0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()