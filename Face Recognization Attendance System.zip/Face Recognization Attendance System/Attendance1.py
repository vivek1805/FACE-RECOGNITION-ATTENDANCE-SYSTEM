import os
from tkinter import *
from tkinter import ttk
from typing import DefaultDict, Pattern
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os
import csv
from tkinter import filedialog


mydata=[]
class Attendance:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1920x1080+0+0")
        self.root.title("face Recognition System")

        self.var_atten_id=StringVar()
        self.var_atten_name=StringVar()
        self.var_atten_roll=StringVar()
        self.var_atten_dep=StringVar()
        self.var_atten_time=StringVar()
        self.var_atten_date=StringVar()
        self.var_atten_attendance=StringVar()

        # first image
        img=Image.open(r"C:\Users\nitis\Documents\Face_Recognition_Projects\photos\pic.jpg")
        img=img.resize((800,200),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)
        f_lbl=Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=0,width=800,height=200)
        # second image
        img1=Image.open(r"C:\Users\nitis\Documents\Face_Recognition_Projects\photos\clg.jpg")
        img1=img1.resize((800,200),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img1)
        f_lbl=Label(self.root,image=self.photoimg1)
        f_lbl.place(x=800,y=0,width=800,height=200)
        # Background Image
        bg_img=Image.open(r"C:\Users\nitis\Documents\Face_Recognition_Projects\photos\computer.jpg")
        bg_img=bg_img.resize((1920,800),Image.ANTIALIAS)
        self.photoimg22=ImageTk.PhotoImage(bg_img)
        bg_lbl=Label(self.root,image=self.photoimg22)
        bg_lbl.place(x=0,y=200,width=1550,height=720)

        title_lbl=Label(bg_lbl,text="ATTENDANCE MANAGEMENT SYSTEM",font=("times new roman",35,"bold"),bg="green",fg="white")
        title_lbl.place(x=0,y=0,width=1550,height=45)

        main_frame=Frame(bg_lbl,bd=2)
        main_frame.place(x=20,y=55,width=1480,height=600)
        #left label frame
        Left_frame=LabelFrame(main_frame,bd=2,bg="white",relief=RIDGE,text="Student Attendance",font=("times new roman",12,"bold"))
        Left_frame.place(x=10,y=10,width=730,height=580)

        img_left=Image.open(r"C:\Users\nitis\Documents\Face_Recognition_Projects\photos\girl.jpeg")
        img_left=img_left.resize((720,130),Image.ANTIALIAS)
        
        self.photoimg_left=ImageTk.PhotoImage(img_left)
        f_lbl=Label(Left_frame,image=self.photoimg_left)
        f_lbl.place(x=5,y=0,width=720,height=130)

        main_inside_frame=Frame(Left_frame,bd=2,relief=RIDGE,bg="white")
        main_inside_frame.place(x=0,y=135,width=720,height=370)

        #Attendance id
        AttendanceId_label=Label(main_inside_frame,text="AttendaceId:",font=("times new roman",13,"bold"),bg="white")
        AttendanceId_label.grid(row=0,column=0,padx=10,pady=5,sticky=W)

        AttendanceID_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_id,font=("times new roman",13,"bold"))
        AttendanceID_entry.grid(row=0,column=1,padx=10,pady=5,sticky=W)
        #student_Name
        studentName_label=Label(main_inside_frame,text="Student Name:",font=("times new roman",13,"bold"),bg="white")
        studentName_label.grid(row=1,column=0,padx=10,pady=5,sticky=W)

        studentName_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_name,font=("times new roman",13,"bold"))
        studentName_entry.grid(row=1,column=1,padx=10,pady=5,sticky=W)
        #Roll
        studentName_label=Label(main_inside_frame,text="Roll:",font=("times new roman",13,"bold"),bg="white")
        studentName_label.grid(row=0,column=2,padx=10,pady=5,sticky=W)

        studentName_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_roll,font=("times new roman",13,"bold"))
        studentName_entry.grid(row=0,column=3,padx=10,pady=5,sticky=W)
        #Date
        date_label=Label(main_inside_frame,text="Date:",font=("times new roman",13,"bold"),bg="white")
        date_label.grid(row=2,column=2,padx=8,pady=5,sticky=W)

        date_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_date,font=("times new roman",13,"bold"))
        date_entry.grid(row=2,column=3,padx=8,pady=5,sticky=W)
        # Department
        dep_label=Label(main_inside_frame,text="Department",font=("times new roman",13,"bold"),bg="white")
        dep_label.grid(row=1,column=2,padx=8)

        dep_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_dep,font=("times new roman",13,"bold"))
        dep_entry.grid(row=1,column=3,padx=8,pady=5,sticky=W)
        #Time
        time_label=Label(main_inside_frame,text="Time:",font=("times new roman",13,"bold"),bg="white")
        time_label.grid(row=2,column=0,padx=8,pady=5,sticky=W)
        time_entry=ttk.Entry(main_inside_frame,width=20,textvariable=self.var_atten_time,font=("times new roman",13,"bold"))
        time_entry.grid(row=2,column=1,padx=8,pady=5,sticky=W)
        # Attendance
        attend_label=Label(main_inside_frame,text="Attendance Status",font=("times new roman",13,"bold"),bg="white")
        attend_label.grid(row=3,column=0,padx=8)

        attend_combo=ttk.Combobox(main_inside_frame,textvariable=self.var_atten_attendance,font=("times new roman",12,"bold"),state="readonly",width=17)
        attend_combo["values"]=("Status","Present","Absent")
        attend_combo.current(0)
        attend_combo.grid(row=3,column=1,padx=2,pady=8)

        #Button Frame
        btn_frame=Frame(main_inside_frame,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=300,width=715,height=35)
        
        save_btn=Button(btn_frame,text="Import csv",command=self.importCsv,width=17,font=("times new roman",13,"bold"),bg="blue",fg="white",cursor="hand2")
        save_btn.grid(row=0,column=0)

        update_btn=Button(btn_frame,text="Export csv",command=self.exportCsv,width=17,font=("times new roman",13,"bold"),bg="blue",fg="white",cursor="hand2")
        update_btn.grid(row=0,column=1)

        delete_btn=Button(btn_frame,text="Update",width=17,font=("times new roman",13,"bold"),bg="blue",fg="white",cursor="hand2")
        delete_btn.grid(row=0,column=2)

        reset_btn=Button(btn_frame,text="Reset",command=self.reset_data,width=17,font=("times new roman",13,"bold"),bg="blue",fg="white",cursor="hand2")
        reset_btn.grid(row=0,column=3)
        


          #right label frame
        Right_frame=LabelFrame(main_frame,bd=2,bg="white",relief=RIDGE,text="Attendace Details",font=("times new roman",12,"bold"))
        Right_frame.place(x=750,y=10,width=720,height=580)

        table_frame=Frame(Right_frame,bd=2,relief=RIDGE)
        table_frame.place(x=5,y=5,width=700,height=450)
        #=============================scroll bar====================
        Scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        Scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)
        self.AttedanceReportTable=ttk.Treeview(table_frame,column=("id","name","roll","department","time","date","attendance"),xscrollcommand=Scroll_x.set,yscrollcommand=Scroll_y.set)
        Scroll_x.pack(side=BOTTOM,fill=X)
        Scroll_y.pack(side=RIGHT,fill=Y)
        Scroll_x.config(command=self.AttedanceReportTable.xview)
        Scroll_y.config(command=self.AttedanceReportTable.yview)
        
        self.AttedanceReportTable.heading("id",text="Attendance ID")
        self.AttedanceReportTable.heading("name",text="Name")
        self.AttedanceReportTable.heading("roll",text="Roll")
        self.AttedanceReportTable.heading("department",text="Department")
        self.AttedanceReportTable.heading("time",text="Time")
        self.AttedanceReportTable.heading("date",text="Date")
        self.AttedanceReportTable.heading("attendance",text="Attendance")
        self.AttedanceReportTable.pack(fill=BOTH,expand=1)
        self.AttedanceReportTable["show"]="headings"

        self.AttedanceReportTable.column("id",width=100)
        self.AttedanceReportTable.column("name",width=100)
        self.AttedanceReportTable.column("roll",width=100)
        self.AttedanceReportTable.column("department",width=100)
        self.AttedanceReportTable.column("time",width=100)
        self.AttedanceReportTable.column("date",width=100)
        self.AttedanceReportTable.column("attendance",width=100)
        self.AttedanceReportTable.pack(fill=BOTH,expand=1)

        self.AttedanceReportTable.bind("<ButtonRelease>",self.get_cursor)

        #============== fetch Data=============================
    def fetchData(self,rows):
        self.AttedanceReportTable.delete(*self.AttedanceReportTable.get_children())
        for i in rows:
              self.AttedanceReportTable.insert("",END,values=i)


    def importCsv(self):
          global mydata
          mydata.clear()
          fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open csv",filetypes=(("csv file","*.csv"),("All files")),parent=self.root)
          with open(fln) as myfile:
            csvread=csv.reader(myfile,delimiter=",")
            for i in csvread:
                  mydata.append(i)
            self.fetchData(mydata)
    #===========export csv====================
    def exportCsv(self):
          try:
            if len(mydata)<1:
                  messagebox.showerror("No Data found to export",parent=self.root)
                  return False
            fln2=filedialog.asksaveasfilename(initialdir=os.getcwd(),title="Open csv",filetypes=(("csv file","*.csv"),("All files")),parent=self.root)
            with open(fln2,mode="w",newline="") as myfile:
              exp_write=csv.writer(myfile,delimiter=",")
              for i in mydata:
                    exp_write.writerow(i)
              messagebox.showinfo("Data Export","your data is exported to "+os.path.basename(fln2)+"successfully")
          except Exception as es:
            messagebox.showerror("Error",f"Due to :{str(es)}",parent=self.root)
    
    def get_cursor(self,event=""):
      cursor_row=self.AttedanceReportTable.focus()
      content=self.AttedanceReportTable.item(cursor_row)
      rows=content['values']
      self.var_atten_id.set(rows[0])
      self.var_atten_name.set(rows[1])
      self.var_atten_roll.set(rows[2])
      self.var_atten_dep.set(rows[3])
      self.var_atten_time.set(rows[4])
      self.var_atten_date.set(rows[5])
      self.var_atten_attendance.set(rows[6])
      #============= reset fun========================

    def reset_data(self):
      self.var_atten_id.set("")
      self.var_atten_name.set("")
      self.var_atten_roll.set("")
      self.var_atten_dep.set("")
      self.var_atten_time.set("")
      self.var_atten_date.set("")
      self.var_atten_attendance.set("")
      



 

                






          



if __name__=="__main__":
    root=Tk()
    obj=Attendance(root)
    root.mainloop()